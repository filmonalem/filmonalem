<!-- <script setup>
import { ref, computed, watchEffect, onMounted } from 'vue';
import BaseHead from '../../../components/BaseHead.vue';
import Table from '../../../components/EasyTable.vue';
import { usePurchaseStore } from "../../../store/stock/stock"
import { storeToRefs } from "pinia";

const stock_store = usePurchaseStore()
var { fetchDailyStock } = usePurchaseStore()

const currentDate = ref(getFormattedDate(new Date()));
const pageName = "Daily Stocks Report"
const dailyPurchases = computed(() => {
    return stock_store.dailyPurchaseData.filter(purchase => purchase.date === currentDate.value);
});
const tableHeader = ["No", "product", "supplierId", "Qty", "Price", "Total", "Action"]

function getFormattedDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

watchEffect(() => {
    currentDate.value = getFormattedDate(new Date());
});

onMounted(() => {
    stock_store.fetchDailyStock();
});
</script>
<template>
    <div>
        <header class="ml-2">
            <BaseHead :Header="pageName" />
        </header>

        <p class="text-gray-600 mb-4">Date: {{ currentDate }}</p>
        <Table :headers="tableHeader" class=" mt-2">
            <tr v-for="(purchase, index) in filteredData" :key="purchase.date"
                class=" mt-2 bg-none  hover:bg-slate-200">
                <td>{{ index + 1 }}</td>
                <td>{{ purchase.medicineId.medicineName }}</td>
                <td>{{ purchase.supplierId.fullName }}</td>
                <td>{{ purchase.quantity }}</td>
                <td>{{ purchase.unitPrice }}</td>
                <td>{{ purchase.totalPayment }}</td>

            </tr>
        </Table>



    </div>
</template> -->
<template>
    <div>
        <h2>Table with Actions</h2>
        <table border="1" cellspacing="0" cellpadding="10">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="item in items" :key="item.id">
                    <td>{{ item.id }}</td>
                    <td>{{ item.name }}</td>
                    <td>
                        <button @click="showDetails(item.id)">Show Details</button>
                    </td>
                </tr>
            </tbody>
        </table>
        <div v-if="selectedItem">
            <h3>Details for ID {{ selectedItem.id }}</h3>
            <p>Name: {{ selectedItem.name }}</p>
            <p>Additional Info: {{ selectedItem.details }}</p>
        </div>
    </div>
</template>

<script setup>
import { ref } from 'vue';

const items = ref([
    { id: 1, name: 'Item 1', details: 'Details about Item 1' },
    { id: 2, name: 'Item 2', details: 'Details about Item 2' },
    { id: 3, name: 'Item 3', details: 'Details about Item 3' },
]);

const selectedItem = ref(null);

function showDetails(itemId) {
    const item = items.value.find((i) => i.id === itemId);
    selectedItem.value = item;
}
</script>